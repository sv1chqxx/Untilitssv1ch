package dev.untilits;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Cooldowns HUD (кулдауны предметов: жемчуг, яблоки, хорус и т.д.) и счётчик тотемов. */
public final class CooldownsHud {
    private CooldownsHud() { }

    public static void render(DrawContext c, MinecraftClient mc) {
        if (mc.player == null) return;
        if (Cfg.D.cooldownHud) drawCooldowns(c, mc);
        if (Cfg.D.totemHud) drawTotems(c, mc);
    }

    private static void drawCooldowns(DrawContext c, MinecraftClient mc) {
        PlayerInventory inv = mc.player.getInventory();
        List<Item> seen = new ArrayList<>();
        List<ItemStack> stacks = new ArrayList<>();
        List<Float> prog = new ArrayList<>();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (st.isEmpty() || seen.contains(st.getItem())) continue;
            float p = mc.player.getItemCooldownManager().getCooldownProgress(st, 0f);
            if (p > 0.01f) { seen.add(st.getItem()); stacks.add(st); prog.add(p); }
        }
        if (stacks.isEmpty()) return;
        int w = 104, rowH = 20, h = 22 + stacks.size() * rowH;
        int x = 8, y = c.getScaledWindowHeight() / 2 - h / 2;
        Gfx.glass(c, x, y, w, h, 9, false);
        Gfx.shadow(c, "Cooldowns", x + 10, y + 7, 0xFFFFFFFF);
        for (int i = 0; i < stacks.size(); i++) {
            int ry = y + 20 + i * rowH;
            c.drawItem(stacks.get(i), x + 6, ry);
            float p = prog.get(i);
            int bx = x + 28, bw = w - 36;
            Gfx.round(c, bx, ry + 5, bw, 5, 2, 0x44FFFFFF);
            Gfx.round(c, bx, ry + 5, Math.max(3, (int) (bw * p)), 5, 2, Gfx.withAlpha(Cfg.D.accent, 240));
        }
    }

    private static void drawTotems(DrawContext c, MinecraftClient mc) {
        PlayerInventory inv = mc.player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (st.isOf(Items.TOTEM_OF_UNDYING)) n += st.getCount();
        }
        String t = String.valueOf(n);
        int w = 22 + Gfx.tw(t) + 10, h = 20;
        int x = c.getScaledWindowWidth() / 2 - w / 2, y = c.getScaledWindowHeight() / 2 + 70;
        Gfx.glass(c, x, y, w, h, 8, false);
        c.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), x + 4, y + 2);
        Gfx.shadow(c, t, x + 24, y + 6, n == 0 ? 0xFFFF6B6B : 0xFFFFFFFF);
    }
}
