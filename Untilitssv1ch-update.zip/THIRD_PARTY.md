# Сторонние материалы

- `assets/untilits/textures/target/*` — текстуры из MaksaiEsp 1.21.11 (в fabric.mod.json указана лицензия MIT), уменьшены до 256 px.
- Режимы Target ESP повторяют набор из MaksaiEsp; код написан заново под Yarn-маппинги и HUD-проекцию Untilits.
- KillFx / NoRender / Cooldowns / FastEXP / Ambience реализованы заново по описанию функций WarpVisuals 1.4b.
  Декомпилированный код WarpVisuals (лицензия All-Rights-Reserved) в проект НЕ скопирован.
