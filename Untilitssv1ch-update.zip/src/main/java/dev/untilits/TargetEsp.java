package dev.untilits;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * Target ESP: эффекты вокруг цели (сущность под прицелом, держится N секунд после потери).
 * Рисуется в экранных координатах через Projector, поэтому работает сквозь стены.
 * Режимы и текстуры — из MaksaiEsp (MIT); код написан заново под движок Untilits.
 */
public final class TargetEsp {
    public static final String[] MODES = {
            "Маркер", "Кольцо", "Призраки", "Орбита", "Кристаллы", "Звёзды",
            "Сердца", "Спираль", "Снег", "Сакура", "Розы"};
    public static final String[] SKINS = {"Маркер 1", "Маркер 2", "Маркер 3", "Маркер 4"};
    public static final String[] COLOR_MODES = {"Акцент", "Свой оттенок", "Радуга"};

    private static final String[] TEX_NAMES = {"marker0", "marker1", "marker2", "marker3", "glow", "star", "heart", "snow", "petal", "rose"};
    private static final int[] TEX_SIZE = {256, 256, 256, 256, 256, 256, 256, 256, 64, 64};
    private static final Identifier[] TEX = new Identifier[TEX_NAMES.length];
    private static final int MARK = 0, GLOW = 4, STAR = 5, HEART = 6, SNOW = 7, PETAL = 8, ROSE = 9;

    static {
        for (int i = 0; i < TEX.length; i++) TEX[i] = Identifier.of("untilits", "textures/target/" + TEX_NAMES[i] + ".png");
    }

    private static final float[] P = new float[3];
    private static final float[] Q = new float[3];

    private static LivingEntity target;
    private static Vec3d lastPos = Vec3d.ZERO;
    private static float lastW = 0.6f, lastH = 1.8f;
    private static long acquired, lastSeen;
    private static float hpShown = -1f;

    private TargetEsp() { }

    /** Текущая цель (для KillFx и HUD). */
    public static LivingEntity target() { return target; }
    public static Vec3d targetPos() { return lastPos; }
    public static float targetHeight() { return lastH; }

    // ------------------------------------------------------------------ тик

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { target = null; return; }
        boolean need = Cfg.D.teOn || Cfg.D.teHud || Cfg.D.killFx;
        if (!need) { target = null; return; }
        long now = System.currentTimeMillis();

        Entity t = mc.targetedEntity;
        if (t instanceof LivingEntity le && le != mc.player && le.isAlive() && le.distanceTo(mc.player) <= 64f) {
            if (target != le) { target = le; acquired = now; hpShown = -1f; }
            lastSeen = now;
        }
        if (target != null) {
            if (target.isAlive()) {
                lastPos = target.getEntityPos();
                lastW = target.getWidth();
                lastH = target.getHeight();
            }
            boolean timeout = now - lastSeen > Cfg.D.teHold * 1000L;
            if (timeout || target.isRemoved() || target.distanceTo(mc.player) > 80f) target = null;
        }
    }

    /** Убийство цели обработал KillFx — забываем её. */
    public static void clear() { target = null; }

    // ------------------------------------------------------------------ цвет и спрайты

    private static int baseColor(float t) {
        return switch (Cfg.D.teColorMode) {
            case 1 -> Gfx.hsv(Cfg.D.teHue / 360f, 0.7f, 1f);
            case 2 -> Gfx.hsv(t * 0.12f, 0.65f, 1f);
            default -> 0xFF000000 | (Cfg.D.accent & 0xFFFFFF);
        };
    }

    private static int tint(int col, float alpha) {
        int a = Math.max(0, Math.min(255, (int) (alpha * 255f)));
        return (a << 24) | (col & 0xFFFFFF);
    }

    /** Один спрайт с центром в (x, y), размером size пикселей, поворотом rot (рад.). */
    private static void sprite(DrawContext c, int tex, float x, float y, float size, float rot, int argb) {
        if (size < 1f || (argb >>> 24) < 3) return;
        int h = Math.max(1, Math.round(size / 2f));
        int ts = TEX_SIZE[tex];
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        if (rot != 0f) m.rotate(rot);
        c.drawTexture(RenderPipelines.GUI_TEXTURED, TEX[tex], -h, -h, 0f, 0f, h * 2, h * 2, ts, ts, ts, ts, argb);
        m.popMatrix();
    }

    /** Пикселей на блок на данной глубине. */
    private static float ppb(double x, double y, double z) {
        if (!Projector.project(x, y, z, P) || !Projector.project(x, y + 1.0, z, Q)) return 0f;
        return (float) Math.hypot(Q[0] - P[0], Q[1] - P[1]);
    }

    private static float rnd(int i, int salt) {
        int h = i * 374761393 + salt * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }

    // ------------------------------------------------------------------ рендер

    public static void render(DrawContext c, MinecraftClient mc, float tp) {
        if (target == null || mc.player == null) return;
        if (Cfg.D.teOn) drawEffect(c, mc, tp);
        if (Cfg.D.teHud) drawHud(c, mc, tp);
    }

    private static void drawEffect(DrawContext c, MinecraftClient mc, float tp) {
        LivingEntity e = target;
        long now = System.currentTimeMillis();
        Vec3d p = e.isAlive() ? e.getLerpedPos(tp) : lastPos;
        double w = lastW, h = lastH;
        float speed = Cfg.D.teSpeed / 100f;
        float t = (now % 3600000L) / 1000f * speed;
        float size = Cfg.D.teSize / 100f;

        float appear = Math.min(1f, (now - acquired) / 250f);
        long left = Cfg.D.teHold * 1000L - (now - lastSeen);
        float fade = left < 350 ? Math.max(0f, left / 350f) : 1f;
        float a = Math.min(appear, fade);
        if (a <= 0.01f) return;

        int col = baseColor(t);
        if (Cfg.D.teHitFlash && e.hurtTime > 0) col = Gfx.lerp(col, 0xFFFF3B3B, Math.min(1f, e.hurtTime / 6f));

        int n = Cfg.D.teCount;
        switch (Cfg.D.teMode) {
            case 0 -> marker(c, p, w, h, t, size, col, a);
            case 1 -> ring(c, p, w, h, t, size, col, a, n);
            case 2 -> ghosts(c, p, w, h, t, size, col, a);
            case 3 -> orbit(c, p, w, h, t, size, col, a);
            case 4 -> crystals(c, p, w, h, t, size, col, a, n);
            case 5 -> rising(c, STAR, p, w, h, t, size, col, a, n, true);
            case 6 -> rising(c, HEART, p, w, h, t, size, 0xFFFF5C8A, a, n, false);
            case 7 -> helix(c, p, w, h, t, size, col, a, n);
            case 8 -> falling(c, SNOW, p, w, h, t, size, 0xFFEAF6FF, a, n);
            case 9 -> falling(c, PETAL, p, w, h, t, size, 0xFFFFB3D1, a, n);
            default -> falling(c, ROSE, p, w, h, t, size, 0xFFFFFFFF, a, n);
        }
    }

    private static void marker(DrawContext c, Vec3d p, double w, double h, float t, float size, int col, float a) {
        double cy = p.y + h * 0.5;
        float ppb = ppb(p.x, cy, p.z);
        if (ppb <= 0f || !Projector.project(p.x, cy, p.z, P)) return;
        float pulse = 1f + 0.06f * (float) Math.sin(t * 3.2f);
        float px = (float) Math.max(w * 1.5, 0.9) * ppb * size * pulse;
        sprite(c, MARK + Cfg.D.teSkin, P[0], P[1], px, t * 1.4f, tint(col, 0.95f * a));
    }

    private static void ring(DrawContext c, Vec3d p, double w, double h, float t, float size, int col, float a, int n) {
        double r = (w * 0.5 + 0.35) * size;
        double y = p.y + h * (0.5 + 0.5 * Math.sin(t * 1.3));
        int dots = Math.max(12, n * 3);
        for (int i = 0; i < dots; i++) {
            double ang = t * 1.2 + i * (Math.PI * 2 / dots);
            double x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r;
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            float k = 0.35f + 0.65f * (float) ((Math.sin(ang * 2 + t * 2) + 1) * 0.5);
            sprite(c, GLOW, P[0], P[1], 0.16f * ppb * size * (0.7f + k * 0.5f), 0f, tint(col, 0.9f * a * k));
        }
    }

    private static void ghosts(DrawContext c, Vec3d p, double w, double h, float t, float size, int col, float a) {
        double r = (w * 0.5 + 0.55) * size;
        for (int g = 0; g < 3; g++) {
            for (int k = 0; k < 9; k++) {
                float tt = t - k * 0.045f;
                double ang = tt * 2.0 + g * (Math.PI * 2 / 3);
                double y = p.y + h * (0.5 + 0.38 * Math.sin(tt * 1.1 + g * 2.1));
                double x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r;
                float ppb = ppb(x, y, z);
                if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
                float f = 1f - k / 9f;
                sprite(c, GLOW, P[0], P[1], 0.42f * ppb * size * f, 0f, tint(col, 0.8f * a * f * f));
            }
        }
    }

    private static void orbit(DrawContext c, Vec3d p, double w, double h, float t, float size, int col, float a) {
        double r = (w * 0.5 + 0.7) * size;
        for (int o = 0; o < 2; o++) {
            double tilt = o == 0 ? 0.6 : -0.6;
            for (int k = 0; k < 7; k++) {
                double ang = (t * 2.4 - k * 0.14) * (o == 0 ? 1 : -1);
                double x0 = Math.cos(ang) * r, z0 = Math.sin(ang) * r;
                double y = p.y + h * 0.55 + z0 * Math.sin(tilt);
                double zz = z0 * Math.cos(tilt);
                float ppb = ppb(p.x + x0, y, p.z + zz);
                if (ppb <= 0f || !Projector.project(p.x + x0, y, p.z + zz, P)) continue;
                float f = 1f - k / 7f;
                sprite(c, k == 0 ? STAR : GLOW, P[0], P[1], (k == 0 ? 0.4f : 0.26f) * ppb * size * f, t * 3f, tint(col, 0.9f * a * f));
            }
        }
    }

    private static void crystals(DrawContext c, Vec3d p, double w, double h, float t, float size, int col, float a, int n) {
        int cnt = Math.max(3, Math.min(10, n / 2 + 2));
        double r = (w * 0.5 + 0.55) * size;
        for (int i = 0; i < cnt; i++) {
            double ang = t * 1.1 + i * (Math.PI * 2 / cnt);
            double y = p.y + h + 0.25 + 0.12 * Math.sin(t * 2 + i);
            double x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r;
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            float px = P[0], py = P[1];
            sprite(c, GLOW, px, py, 0.55f * ppb * size, 0f, tint(col, 0.35f * a));
            sprite(c, STAR, px, py, 0.34f * ppb * size, (float) ang + t, tint(col, 0.95f * a));
        }
    }

    private static void rising(DrawContext c, int tex, Vec3d p, double w, double h, float t, float size, int col, float a, int n, boolean spin) {
        for (int i = 0; i < n; i++) {
            float life = (t * 0.45f + rnd(i, 1)) % 1f;
            double ang = rnd(i, 2) * Math.PI * 2 + life * 2.2;
            double r = (w * 0.5 + 0.15 + rnd(i, 3) * 0.55) * size;
            double x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r;
            double y = p.y + life * (h + 0.4);
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            float f = (float) Math.sin(life * Math.PI);
            sprite(c, tex, P[0], P[1], (0.14f + rnd(i, 4) * 0.16f) * ppb * size * (0.5f + f * 0.5f),
                    spin ? t * 2f + i : 0f, tint(col, 0.95f * a * f));
        }
    }

    private static void helix(DrawContext c, Vec3d p, double w, double h, float t, float size, int col, float a, int n) {
        double r = (w * 0.5 + 0.4) * size;
        int per = Math.max(6, n);
        for (int s = 0; s < 2; s++) {
            for (int i = 0; i < per; i++) {
                float f = i / (float) per;
                double ang = t * 2.0 + f * Math.PI * 4 + s * Math.PI;
                double x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r;
                double y = p.y + f * (h + 0.2);
                float ppb = ppb(x, y, z);
                if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
                sprite(c, GLOW, P[0], P[1], 0.17f * ppb * size, 0f, tint(col, 0.85f * a * (0.4f + 0.6f * f)));
            }
        }
    }

    private static void falling(DrawContext c, int tex, Vec3d p, double w, double h, float t, float size, int col, float a, int n) {
        for (int i = 0; i < n; i++) {
            float life = (t * 0.3f + rnd(i, 5)) % 1f;
            double ang = rnd(i, 6) * Math.PI * 2 + Math.sin(life * 6 + i) * 0.4;
            double r = (w * 0.5 + 0.2 + rnd(i, 7) * 0.7) * size;
            double x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r;
            double y = p.y + h + 0.4 - life * (h + 0.6);
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            float f = (float) Math.sin(life * Math.PI);
            sprite(c, tex, P[0], P[1], (0.16f + rnd(i, 8) * 0.14f) * ppb * size, t * 1.5f + i, tint(col, 0.95f * a * Math.min(1f, f * 1.6f)));
        }
    }

    // ------------------------------------------------------------------ карточка цели

    private static void drawHud(DrawContext c, MinecraftClient mc, float tp) {
        LivingEntity e = target;
        if (e == null) return;
        long now = System.currentTimeMillis();
        long left = Cfg.D.teHold * 1000L - (now - lastSeen);
        if (left < 0) return;
        float hp = Math.max(0f, e.getHealth()), max = Math.max(1f, e.getMaxHealth());
        if (hpShown < 0f) hpShown = hp;
        hpShown += (hp - hpShown) * 0.12f;
        String name = e.getName().getString();
        String txt = Math.round(hp + e.getAbsorptionAmount()) + " HP";
        String dist = String.format("%.1f м", mc.player.distanceTo(e));

        int w = Math.max(110, Gfx.tw(name) + Gfx.tw(dist) + 28), h = 44;
        int x = c.getScaledWindowWidth() / 2 + 36, y = c.getScaledWindowHeight() / 2 + 28;
        Gfx.glass(c, x, y, w, h, 8, false);
        Gfx.shadow(c, name, x + 8, y + 6, Friends.is(name) ? 0xFF55FF55 : 0xFFFFFFFF);
        Gfx.text(c, dist, x + w - 8 - Gfx.tw(dist), y + 6, 0x99FFFFFF);
        int bx = x + 8, bw = w - 16, by = y + 20;
        Gfx.round(c, bx, by, bw, 6, 3, 0x44FFFFFF);
        float f = Math.max(0f, Math.min(1f, hpShown / max));
        int fw = Math.max(4, (int) (bw * f));
        int hc = f > 0.5f ? 0xFF55D68A : f > 0.25f ? 0xFFFFB454 : 0xFFFF5C5C;
        Gfx.round(c, bx, by, fw, 6, 3, hc);
        Gfx.text(c, txt, bx, y + 31, Gfx.TEXT);
    }
}
