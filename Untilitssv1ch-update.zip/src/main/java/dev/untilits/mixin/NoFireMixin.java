package dev.untilits.mixin;

import dev.untilits.Cfg;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: огонь на экране. */
@Mixin(InGameOverlayRenderer.class)
public abstract class NoFireMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void untilits$noFire(CallbackInfo ci) {
        if (Cfg.D.nrFire) ci.cancel();
    }
}
