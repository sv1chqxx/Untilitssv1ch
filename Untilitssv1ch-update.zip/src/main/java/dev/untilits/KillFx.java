package dev.untilits;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Эффекты убийства цели (Молния / Частицы / Астрал / Разлом). Цель берётся из TargetEsp.
 * Реализовано заново по описанию функций WarpVisuals KillEffects (код оригинала не используется).
 */
public final class KillFx {
    public static final String[] MODES = {"Молния", "Частицы", "Астрал", "Разлом"};

    private static final Identifier GLOW = Identifier.of("untilits", "textures/target/glow.png");
    private static final Identifier STAR = Identifier.of("untilits", "textures/target/star.png");

    private static final class Fx {
        final Vec3d pos; final double h; final long born; final int mode; final long seed;
        Fx(Vec3d pos, double h, int mode) { this.pos = pos; this.h = h; this.born = System.currentTimeMillis(); this.mode = mode; this.seed = born ^ 0x9E3779B97F4A7C15L; }
    }

    private static final List<Fx> LIST = new ArrayList<>();
    private static final float[] P = new float[3];
    private static final float[] Q = new float[3];
    private static LivingEntity watched;

    private KillFx() { }

    public static void tick(MinecraftClient mc) {
        if (!Cfg.D.killFx || mc.world == null) { LIST.clear(); watched = null; return; }
        LivingEntity t = TargetEsp.target();
        if (t != null) watched = t;
        if (watched != null && watched.isDead()) {
            if (mc.player != null && watched.distanceTo(mc.player) < 80f) {
                LIST.add(new Fx(watched.getEntityPos(), watched.getHeight(), Cfg.D.killMode));
            }
            if (watched == TargetEsp.target()) TargetEsp.clear();
            watched = null;
        }
        long now = System.currentTimeMillis();
        for (Iterator<Fx> it = LIST.iterator(); it.hasNext(); ) if (now - it.next().born > 6500) it.remove();
    }

    private static float rnd(long seed, int i) {
        long h = seed + i * 0x9E3779B97F4A7C15L;
        h = (h ^ (h >>> 30)) * 0xBF58476D1CE4E5B9L;
        h = (h ^ (h >>> 27)) * 0x94D049BB133111EBL;
        h ^= h >>> 31;
        return ((h >>> 11) & 0xFFFFFF) / (float) 0x1000000;
    }

    private static void dot(DrawContext c, Identifier tex, float x, float y, float size, float rot, int argb) {
        if (size < 1f || (argb >>> 24) < 3) return;
        int h = Math.max(1, Math.round(size / 2f));
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        if (rot != 0f) m.rotate(rot);
        c.drawTexture(RenderPipelines.GUI_TEXTURED, tex, -h, -h, 0f, 0f, h * 2, h * 2, 256, 256, 256, 256, argb);
        m.popMatrix();
    }

    private static float ppb(double x, double y, double z) {
        if (!Projector.project(x, y, z, P) || !Projector.project(x, y + 1.0, z, Q)) return 0f;
        return (float) Math.hypot(Q[0] - P[0], Q[1] - P[1]);
    }

    private static void line(DrawContext c, float x0, float y0, float x1, float y1, int col, int th) {
        int steps = Math.max(1, (int) Math.hypot(x1 - x0, y1 - y0) / 2);
        for (int i = 0; i <= steps; i++) {
            float f = i / (float) steps;
            int x = Math.round(x0 + (x1 - x0) * f), y = Math.round(y0 + (y1 - y0) * f);
            c.fill(x - th / 2, y - th / 2, x - th / 2 + th, y - th / 2 + th, col);
        }
    }

    public static void render(DrawContext c, MinecraftClient mc, float tp) {
        if (LIST.isEmpty()) return;
        long now = System.currentTimeMillis();
        float sc = Cfg.D.killScale / 100f;
        int accent = 0xFFFFFF & Cfg.D.accent;
        for (Fx f : LIST) {
            float t = (now - f.born) / 1000f;
            switch (f.mode) {
                case 0 -> lightning(c, f, t, sc);
                case 1 -> particles(c, f, t, sc, accent);
                case 2 -> astral(c, f, t, sc, accent);
                default -> rift(c, f, t, sc);
            }
        }
    }

    private static void lightning(DrawContext c, Fx f, float t, float sc) {
        if (t > 1.2f) return;
        float a = Math.max(0f, 1f - t / 1.2f);
        if (t < 0.18f) c.fill(0, 0, c.getScaledWindowWidth(), c.getScaledWindowHeight(), Gfx.withAlpha(0xFFFFFF, (int) (110 * (1f - t / 0.18f))));
        float px = 0, py = 0;
        boolean has = false;
        int seg = 12;
        for (int i = 0; i <= seg; i++) {
            float k = i / (float) seg;
            double x = f.pos.x + (rnd(f.seed, i) - 0.5) * 1.4 * (1 - k) * sc;
            double z = f.pos.z + (rnd(f.seed, i + 50) - 0.5) * 1.4 * (1 - k) * sc;
            double y = f.pos.y + 14 * (1 - k);
            if (!Projector.project(x, y, z, P)) { has = false; continue; }
            if (has) {
                line(c, px, py, P[0], P[1], Gfx.withAlpha(0x9EC8FF, (int) (110 * a)), 5);
                line(c, px, py, P[0], P[1], Gfx.withAlpha(0xFFFFFF, (int) (255 * a)), 2);
            }
            px = P[0]; py = P[1]; has = true;
        }
        float ppb = ppb(f.pos.x, f.pos.y + 0.2, f.pos.z);
        if (ppb > 0f && Projector.project(f.pos.x, f.pos.y + 0.2, f.pos.z, P))
            dot(c, GLOW, P[0], P[1], ppb * 2.2f * sc * (0.6f + t), 0f, Gfx.withAlpha(0x9EC8FF, (int) (200 * a)));
    }

    private static void particles(DrawContext c, Fx f, float t, float sc, int accent) {
        if (t > 2.2f) return;
        int n = 36;
        for (int i = 0; i < n; i++) {
            double ang = rnd(f.seed, i) * Math.PI * 2;
            double sp = (1.2 + rnd(f.seed, i + 100) * 2.4) * sc;
            double up = 2.0 + rnd(f.seed, i + 200) * 3.0;
            double x = f.pos.x + Math.cos(ang) * sp * t;
            double z = f.pos.z + Math.sin(ang) * sp * t;
            double y = f.pos.y + f.h * 0.5 + up * t - 4.9 * t * t;
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            float a = Math.max(0f, 1f - t / 2.2f);
            int col = Gfx.lerp(0xFF000000 | accent, 0xFFFFFFFF, rnd(f.seed, i + 300) * 0.5f);
            dot(c, GLOW, P[0], P[1], ppb * (0.12f + rnd(f.seed, i + 400) * 0.12f), 0f, Gfx.withAlpha(col, (int) (255 * a)));
        }
    }

    private static void astral(DrawContext c, Fx f, float t, float sc, int accent) {
        if (t > 3.2f) return;
        float a = Math.max(0f, 1f - t / 3.2f);
        double cy = f.pos.y + f.h * 0.5;
        for (int ring = 0; ring < 3; ring++) {
            float rt = t - ring * 0.25f;
            if (rt < 0f) continue;
            double r = (0.4 + rt * 1.6) * sc;
            for (int i = 0; i < 28; i++) {
                double ang = i * (Math.PI * 2 / 28) + rt * 1.5;
                double x = f.pos.x + Math.cos(ang) * r, z = f.pos.z + Math.sin(ang) * r;
                float ppb = ppb(x, cy, z);
                if (ppb <= 0f || !Projector.project(x, cy, z, P)) continue;
                dot(c, GLOW, P[0], P[1], ppb * 0.18f, 0f, Gfx.withAlpha(accent, (int) (230 * a)));
            }
        }
        for (int i = 0; i < 14; i++) {
            double ang = rnd(f.seed, i) * Math.PI * 2;
            double r = (0.3 + rnd(f.seed, i + 60) * 1.2) * sc;
            double x = f.pos.x + Math.cos(ang + t) * r, z = f.pos.z + Math.sin(ang + t) * r;
            double y = f.pos.y + t * (0.8 + rnd(f.seed, i + 90));
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            dot(c, STAR, P[0], P[1], ppb * 0.28f, t * 2 + i, Gfx.withAlpha(0xFFFFFF, (int) (255 * a)));
        }
    }

    private static void rift(DrawContext c, Fx f, float t, float sc) {
        if (t > 3.5f) return;
        float a = Math.min(1f, t * 3f) * Math.max(0f, 1f - (t - 2.5f) / 1.0f);
        if (a <= 0f) return;
        double cy = f.pos.y + f.h * 0.5;
        for (int i = 0; i < 40; i++) {
            double ang = i * (Math.PI * 2 / 40) - t * 2.2;
            double r = (1.3 - 0.35 * Math.min(1f, t)) * sc * (0.8 + 0.2 * Math.sin(ang * 3 + t * 4));
            double x = f.pos.x + Math.cos(ang) * r, z = f.pos.z + Math.sin(ang) * r;
            double y = cy + Math.sin(ang * 2 + t * 3) * 0.15;
            float ppb = ppb(x, y, z);
            if (ppb <= 0f || !Projector.project(x, y, z, P)) continue;
            dot(c, GLOW, P[0], P[1], ppb * 0.2f, 0f, Gfx.withAlpha(i % 2 == 0 ? 0x7A3BFF : 0x1A0A33, (int) (240 * a)));
        }
        for (int i = 0; i < 18; i++) {
            double ang = rnd(f.seed, i) * Math.PI * 2;
            double k = (rnd(f.seed, i + 70) + t * 0.5) % 1.0;
            double r = (2.2 * (1 - k)) * sc;
            double x = f.pos.x + Math.cos(ang) * r, z = f.pos.z + Math.sin(ang) * r;
            float ppb = ppb(x, cy, z);
            if (ppb <= 0f || !Projector.project(x, cy, z, P)) continue;
            dot(c, GLOW, P[0], P[1], ppb * 0.13f, 0f, Gfx.withAlpha(0xB48CFF, (int) (230 * a * (1 - k))));
        }
    }
}
