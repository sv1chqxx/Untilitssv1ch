package dev.untilits;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;

/** Конфиг мода (config/untilits.json). */
public final class Cfg {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static Data D = new Data();

    /** Метка (waypoint). */
    public static final class WP {
        public String name = "Метка";
        public int x, y, z;
        public String dim = "minecraft:overworld";
        public int color = 0x5B8CFF;
        public boolean visible = true;
        public WP() { }
        public WP(String name, int x, int y, int z, String dim, int color) {
            this.name = name; this.x = x; this.y = y; this.z = z; this.dim = dim; this.color = color;
        }
    }

    public static final class Data {
        // оформление
        public int accent = 0xFF5B8CFF;
        public int glass = 0x101A2E;     // RGB тона стекла
        public int glassPct = 78;        // прозрачность стекла, %

        // HUD (аналог KronHUD)
        public boolean fps = true;
        public boolean cps = true;
        public boolean coords = false;
        public boolean ping = true;
        public boolean keys = false;
        public boolean armor = false;
        public int hudCorner = 0;        // 0 лево-верх, 1 право-верх, 2 лево-низ, 3 право-низ

        // эффекты
        public boolean damageNumbers = true;
        public int dmgScale = 100;
        public boolean blood = true;
        public int bloodAmount = 100;

        // скрытое меню
        public boolean esp = false;
        public int espRange = 128;
        public boolean weak = false;      // подсветка слабых мест (игроки с низким HP)
        public int weakHp = 8;
        public boolean chestEsp = false;
        public int chestRange = 64;
        public boolean chestSpawners = false;
        public int freecamSpeed = 5;
        public boolean espGlow = false;   // ванильный контур (тяжёлый для FPS)
        public boolean espMobs = false;
        public boolean espItems = false;
        public boolean tracers = false;
        public int tracerRange = 128;
        public boolean tracersMobs = false;
        public boolean tracersItems = false;
        public boolean names = false;
        public int nameRange = 256;
        public boolean nameHp = true;
        public boolean nameItems = true;
        public boolean sysHud = false;
        public int sysX = -1;
        public int sysY = 8;

        public boolean kbHud = false;     // таблица включённых кейбиндов
        public int kbX = -1;
        public int kbY = 40;
        public List<String> friends = new ArrayList<>();
        public Map<String, Integer> binds = new LinkedHashMap<>();

        public boolean trapTimer = false;
        public int trapScale = 100;
        public boolean zeroTcp = false;
        public boolean zeroJump = false;
        public boolean zeroAttack = false;
        public boolean zeroRaycast = false;
        public boolean zeroSnap = false;

        // обычное меню: метки, эффекты, предсказания, броня
        public boolean wpEnabled = true;
        public boolean wpDeath = true;
        public int wpMaxDist = 0;          // 0 = без ограничения
        public List<WP> waypoints = new ArrayList<>();
        public boolean potionHud = false;
        public boolean predict = false;
        public boolean predictFlying = true;
        public boolean armorOver = false;
        public boolean armorWarn = true;
        public int armorWarnPct = 15;

        // Target ESP (вкладка в обычном меню)
        public boolean teOn = false;
        public int teMode = 0;
        public int teSkin = 0;            // скин маркера 0..3
        public int teSize = 100;          // %
        public int teSpeed = 100;         // %
        public int teCount = 12;
        public int teColorMode = 0;       // 0 акцент, 1 свой оттенок, 2 радуга
        public int teHue = 210;
        public int teHold = 3;            // сек. после потери цели
        public boolean teHitFlash = true;
        public boolean teHud = true;      // карточка цели

        // эффекты убийства
        public boolean killFx = false;
        public int killMode = 0;
        public int killScale = 100;

        // визуал / утилиты
        public boolean nrScoreboard = false;
        public boolean nrBossBar = false;
        public boolean nrTitles = false;
        public boolean nrFire = false;
        public boolean clearWeather = false;
        public boolean fastExp = false;
        public boolean cooldownHud = false;
        public boolean totemHud = false;

        public String pass = "";
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("untilits.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                    Data d = GSON.fromJson(r, Data.class);
                    if (d != null) D = d;
                }
            }
        } catch (Throwable ignored) { }
        sanitize();
    }

    private static void sanitize() {
        D.accent |= 0xFF000000;
        D.glass &= 0xFFFFFF;
        D.glassPct = clamp(D.glassPct, 30, 98);
        D.dmgScale = clamp(D.dmgScale, 50, 250);
        D.bloodAmount = clamp(D.bloodAmount, 10, 300);
        D.espRange = clamp(D.espRange, 8, 512);
        D.tracerRange = clamp(D.tracerRange, 8, 512);
        D.weakHp = clamp(D.weakHp, 1, 20);
        D.chestRange = clamp(D.chestRange, 8, 128);
        D.freecamSpeed = clamp(D.freecamSpeed, 1, 30);
        D.nameRange = clamp(D.nameRange, 8, 512);
        D.hudCorner = clamp(D.hudCorner, 0, 3);
        D.trapScale = clamp(D.trapScale, 40, 250);
        if (D.friends == null) D.friends = new ArrayList<>();
        if (D.binds == null) D.binds = new LinkedHashMap<>();
        if (D.waypoints == null) D.waypoints = new ArrayList<>();
        D.armorWarnPct = clamp(D.armorWarnPct, 5, 50);
        D.wpMaxDist = clamp(D.wpMaxDist, 0, 5000);
        D.teMode = clamp(D.teMode, 0, 10);
        D.teSkin = clamp(D.teSkin, 0, 3);
        D.teSize = clamp(D.teSize, 40, 250);
        D.teSpeed = clamp(D.teSpeed, 20, 300);
        D.teCount = clamp(D.teCount, 3, 40);
        D.teColorMode = clamp(D.teColorMode, 0, 2);
        D.teHue = clamp(D.teHue, 0, 359);
        D.teHold = clamp(D.teHold, 0, 10);
        D.killMode = clamp(D.killMode, 0, 3);
        D.killScale = clamp(D.killScale, 50, 250);
        if (D.pass == null) D.pass = "";
    }

    public static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    public static int glassAlpha() { return D.glassPct * 255 / 100; }

    public static void save() {
        sanitize();
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            try (Writer w = Files.newBufferedWriter(f, StandardCharsets.UTF_8)) { GSON.toJson(D, w); }
        } catch (Throwable t) {
            System.err.println("[untilits] не удалось сохранить конфиг: " + t);
        }
    }

    private static String hash(String code) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(("untilits:" + code).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(h);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    public static void setPassword(String code) { D.pass = hash(code); save(); }
    public static boolean hasPassword() { return D.pass != null && !D.pass.isEmpty(); }
    public static boolean checkPassword(String code) { return hasPassword() && D.pass.equals(hash(code)); }

    private Cfg() { }
}
