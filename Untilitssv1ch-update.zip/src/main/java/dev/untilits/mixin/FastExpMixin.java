package dev.untilits.mixin;

import dev.untilits.Cfg;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** FastEXP: бутылочки опыта кидаются без задержки (отдельный миксин, чтобы не ломать остальные при смене маппингов). */
@Mixin(MinecraftClient.class)
public abstract class FastExpMixin {
    @Shadow private int itemUseCooldown;

    @Inject(method = "doItemUse", at = @At("HEAD"), require = 0)
    private void untilits$fastExp(CallbackInfo ci) {
        if (!Cfg.D.fastExp) return;
        MinecraftClient mc = (MinecraftClient) (Object) this;
        if (mc.player != null && (mc.player.getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE)
                || mc.player.getOffHandStack().isOf(Items.EXPERIENCE_BOTTLE))) itemUseCooldown = 0;
    }
}
